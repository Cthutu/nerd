import sys,os,json,hashlib,subprocess,statistics
from pathlib import Path
sys.path.insert(0,'/home/matt/nerd/build')
from benchmark_compiler import invoke
root=Path('/home/matt/nerd'); out=Path(__file__).parent
os.sched_setaffinity(0,{2})
env=dict(os.environ,NERD_LIB_PATH=str(root/'mods'),NERD_DEBUG_KEEP_LINK_LLVM='1')
for k in ['NERD_PROFILE','NERD_PROFILE_LOCKS','NERD_MEMORY_PROFILE']: env.pop(k,None)
compilers={'before':'/tmp/nerd-before-symbol-set','after':str(root/'_bin/nerd')}
data={'metadata':{'cpu':2,'samples':5,'profiles':3,'hashes':{k:hashlib.sha256(Path(v).read_bytes()).hexdigest() for k,v in compilers.items()}},'runs':[]}
for name,source in [('wide50',Path('/tmp/nerd-scale-bench-Xo1BUG/wide-50/main.n')),('wide1000',Path('/tmp/nerd-scale-bench-Xo1BUG/wide-1000/main.n')),('pixels',root/'examples/pixels/pixels.n')]:
 row={'name':name,'compilers':{k:{'samples':[],'profiles':[]} for k in compilers}}; ref=None
 for i in range(9):
  for k in (['before','after'] if i%2==0 else ['after','before']):
   binary=out/'program'; sample,records=invoke([compilers[k],'b','--jobs','1','-o',str(binary),str(source)],dict(env,NERD_PROFILE='1') if i>=6 else env)
   h=hashlib.sha256(Path(str(binary)+'.link.ll').read_bytes()).hexdigest()
   if ref is None: ref=h
   assert h==ref,(name,k)
   if name!='pixels': subprocess.run([str(binary)],check=True,timeout=10)
   if 1<=i<=5: row['compilers'][k]['samples'].append(sample)
   if i>=6: row['compilers'][k]['profiles'].append({'sample':sample,'records':records})
 for k,c in row['compilers'].items():
  c['wall_ms']=statistics.median(s['wall_ns'] for s in c['samples'])/1e6
  c['combine_ms']=statistics.median(sum(r['wall_ns'] for r in p['records'] if r.get('phase')=='combine LLVM text') for p in c['profiles'])/1e6
 row['llvm_sha256']=ref; data['runs'].append(row); (out/'results.json').write_text(json.dumps(data,indent=2))
 print(name,[(k,c['wall_ms'],c['combine_ms']) for k,c in row['compilers'].items()],flush=True)
