from pathlib import Path
import argparse

def generate(directory,n,shape):
    folder=directory/f'{shape}-{n}'; folder.mkdir(exist_ok=True)
    count=4 if shape=='heavy' else n
    common='pub Point :: plex {\n x i32\n y i32\n}\npub id :: fn [T] (value: T) -> T { return value }\n'
    if shape=='shared': (folder/'base.n').write_text(common)
    expected=0
    for i in range(count):
        fcount=24*(n//4+(i<n%4)) if shape=='heavy' else 24
        prefix='use base\n' if shape=='shared' else common
        if shape=='chain' and i+1<count: prefix+=f'next :: use m{i+1}\n'
        functions=[]
        for j in range(fcount):
            functions.append(f'f{j} :: fn (x: i32) -> i32 {{\n p: Point\n p.x = id[i32](x)\n p.y = {j%17}\n return p.x + p.y\n}}\n')
        value=' + '.join(f'f{j}(x)' for j in range(fcount))
        if shape=='chain' and i+1<count: value+=' + next.value(x)'
        (folder/f'm{i}.n').write_text(prefix+''.join(functions)+f'pub value :: fn (x: i32) -> i32 {{ return {value} }}\n')
        expected+=sum(1+j%17 for j in range(fcount))
    imported=range(1) if shape=='chain' else range(count)
    (folder/'main.n').write_text(''.join(f'm{i} :: use m{i}\n' for i in imported)+'main :: fn () -> i32 {\n result := '+' + '.join(f'm{i}.value(1)' for i in imported)+f'\n on result != {expected} => return 1\n return 0\n}}\n')
    return folder

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    args.directory.mkdir(parents=True,exist_ok=True)
    for n in [50,200,1000]:
        for shape in ['wide','shared','chain','heavy']:
            generate(args.directory,n,shape)
