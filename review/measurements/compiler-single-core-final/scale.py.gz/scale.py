import os,sys,json,hashlib,subprocess,statistics,platform
from pathlib import Path
sys.path.insert(0,'/home/matt/nerd/build')
from benchmark_compiler import invoke
ROOT=Path('/home/matt/nerd'); OUT=Path(__file__).parent; INPUTS=Path('/tmp/nerd-scale-bench-Xo1BUG')
os.sched_setaffinity(0,set(range(16)))
variants={'before-j1':('/tmp/nerd-singlecore-start','1'),'final-j1':(str(ROOT/'_bin/nerd'),'1'),'final-j4':(str(ROOT/'_bin/nerd'),'4'),'final-auto':(str(ROOT/'_bin/nerd'),'auto')}
env=dict(os.environ,NERD_LIB_PATH=str(ROOT/'mods'),NERD_DEBUG_KEEP_LINK_LLVM='1')
for k in ['NERD_PROFILE','NERD_PROFILE_LOCKS','NERD_MEMORY_PROFILE','NERD_DEBUG_LLVM_SIDECARS']:env.pop(k,None)
data={'metadata':{'affinity':list(range(16)),'auto_ceiling':8,'samples':3,'warmups':1,'profile_samples':1,'target':'debug','order':'rotate variants each round; separate profile round','before_commit':'990cfb5a','after_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=ROOT).strip(),'compiler_hashes':{k:hashlib.sha256(Path(c).read_bytes()).hexdigest() for k,(c,j) in variants.items()},'platform':platform.platform()},'runs':[]}
def save(): (OUT/'scale.json').write_text(json.dumps(data,indent=2)+'\n')
for n in [50,200,1000]:
 for shape in ['wide','shared','chain','heavy']:
  folder=INPUTS/f'{shape}-{n}'; binary=OUT/'scale-program'; ir=Path(str(binary)+'.link.ll'); source=folder/'main.n'
  row={'units':n,'shape':shape,'files':len(list(folder.glob('*.n'))),'source_bytes':sum(p.stat().st_size for p in folder.glob('*.n')),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.n')},'variants':{k:{'samples':[]} for k in variants}}
  reference=None; data['runs'].append(row); save()
  for iteration in range(5):
   keys=list(variants); offset=iteration%len(keys)
   for key in keys[offset:]+keys[:offset]:
    c,j=variants[key]; print(f'RUN {n} {shape} round={iteration} {key}',flush=True)
    command=['timeout','240',c,'b','--jobs',j,'-o',str(binary),str(source)]
    sample,records=invoke(command,dict(env,NERD_PROFILE='1') if iteration==4 else env)
    h=hashlib.sha256(ir.read_bytes()).hexdigest()
    if reference is None:reference=h
    assert h==reference,(n,shape,key,'LLVM mismatch')
    subprocess.run([str(binary)],check=True,timeout=10)
    cell=row['variants'][key]
    if 1<=iteration<=3:cell['samples'].append(sample)
    if iteration==4:
     front=[r for r in records if r.get('stage')=='front-end' and r.get('kind')=='phase']
     end=[r for r in records if r.get('phase')=='combine LLVM text']
     cell['profile']={'sample':sample,'records':records,'source_to_ir_ns':max(r['start_ns']+r['wall_ns'] for r in end)-min(r['start_ns'] for r in front)}
    save()
  for key,cell in row['variants'].items():
   cell['wall_ms']=statistics.median(s['wall_ns'] for s in cell['samples'])/1e6
   cell['cpu_seconds']=statistics.median(s['user_seconds']+s['system_seconds'] for s in cell['samples'])
   cell['rss_mib']=statistics.median(s['max_process_rss_bytes'] for s in cell['samples'])/1048576
  row['llvm_sha256']=reference; save()
  print('DONE',n,shape,[(k,round(v['wall_ms'],1)) for k,v in row['variants'].items()],flush=True)
