from pathlib import Path
import json,statistics
W=Path(__file__).parent
load=lambda n:json.loads((W/n).read_text()) if (W/n).exists() else None
s=['# Single-core completion benchmark','', '2026-09-22, Linux x86-64, Ryzen 7950X, LLVM 22.1.8. Final compiler implementation: `6dd4b36e`. Original compiler: `a15e965d`; turn-start compiler: `990cfb5a`.','', 'The remaining arithmetic stack failures in semantic inference and HIR lowering are fixed for the 6,000-term regression. Semantic scope queries use existing parser side tables instead of repeated whole-AST scans. The withdrawn dependency scheduler stays removed; the established batch scheduler and opt-in worker policy remain.','', 'Linux correctness: 1,122 fixtures, zero failures, nine platform skips; 280 C differential cases at two optimisation levels; 6,000-term debug/release/ASan/TSan checks with jobs=1/4; frontend output/diagnostic/runtime parity and Windows-runner unit tests. Native Windows/macOS execution is still pending.','', '## Method','', 'Original and turn-start comparisons use one worker pinned to CPU 2, one warmup and seven alternating/rotating unprofiled samples per cell. Turn-start phase envelopes use three separate intrusive profile samples. The worker sweep uses five samples and one separate profile; scaled inputs use three samples and one profile. No compiler builds or tests ran concurrently with final timing runs. Existing Wine/desktop processes were left running, so small differences remain inconclusive. The governor was `performance`; frequency/SMT-sibling activity was not controlled.','', 'Worker/scaled comparisons share a mask of 16 physical cores (CPU IDs 0–15), so `auto` has an eight-worker ceiling. This mask differs from normal unrestricted 32-logical-CPU discovery. The actual automatic phase budget can be lower than its ceiling. All timing tables are medians. Speedup = before / after.','', 'CPU samples include waited child processes on this Linux host. RSS is the largest individual process peak, not aggregate process-tree memory. Profiles measure elapsed first frontend phase to completed LLVM combination; external LLVM tool time is excluded from that envelope.','']
x=load('original.json')
if x:
 s+=['## Original compiler → final, one worker','','| Project | Check before → final (ms) | Debug build before → final (ms) | Release build before → final (ms) | Debug / release speedup |','|---|---:|---:|---:|---:|']
 for name in dict.fromkeys(r['scenario'] for r in x['runs']):
  rows={r['mode']:r for r in x['runs'] if r['scenario']==name}
  if set(rows)<{'check','debug','release'}:continue
  vals={m:(rows[m]['variants']['main']['median_wall_ns']/1e6,rows[m]['variants']['experiment-j1']['median_wall_ns']/1e6) for m in rows}
  cell=lambda m:f'{vals[m][0]:.2f} → {vals[m][1]:.2f}'
  s+=[f"| {name} | {cell('check')} | {cell('debug')} | {cell('release')} | {vals['debug'][0]/vals['debug'][1]:.2f}× / {vals['release'][0]/vals['release'][1]:.2f}× |"]
 s+=['','This cumulative comparison includes earlier correctness fixes and the change from the historical Clang subprocess backend to direct LLVM tools. The final Nerd compiler never invokes Clang for normal builds. Original/final real-example LLVM differs; synthetic stability and runtime results are recorded separately. Do not attribute all cumulative gains to this pass.','']
if x:
 s+=['### Real-project CPU and peak-process memory','','| Project | Mode | Original CPU s / RSS MiB | Final CPU s / RSS MiB |','|---|---|---:|---:|']
 for r in x['runs']:
  if r['scenario'] not in ['dungeon','pixels']:continue
  cells=[]
  for k in ['main','experiment-j1']:
   samples=r['variants'][k]['samples']
   cpu=statistics.median(v['user_seconds']+v['system_seconds'] for v in samples)
   rss=statistics.median(v['max_process_rss_bytes'] for v in samples)/1048576
   cells.append(f'{cpu:.3f} / {rss:.1f}')
  s+=[f"| {r['scenario']} | {r['mode']} | "+' | '.join(cells)+' |']
 s+=['']
x=load('paired.json')
if x:
 s+=['## This pass: turn start → final, one worker','','| Project | Target | Before → final build (ms) | Speedup | Before → final source-to-IR (ms) |','|---|---|---:|---:|---:|']
 for r in x['runs']:
  a,b=r['before'],r['after'];s+=[f"| {r['scenario']} | {r['target']} | {a['median_wall_ns']/1e6:.2f} → {b['median_wall_ns']/1e6:.2f} | {a['median_wall_ns']/b['median_wall_ns']:.2f}× | {a['median_source_to_ir_ns']/1e6:.2f} → {b['median_source_to_ir_ns']/1e6:.2f} |"]
 s+=['','Every before/after LLVM comparison in this matrix is byte-identical. The previous single-module regression is evaluated here against the turn-start compiler, which already included the LLVM-depth fix. The additional scope-query changes remove substantially more work than that historical regression introduced.','']
x=load('workers.json')
if x:
 s+=['## Final compiler worker sweep','','| Project | Target | 1 | 2 | 4 | 8 | 16 | auto |','|---|---|---:|---:|---:|---:|---:|---:|']
 for r in x['runs']:
  s+=[f"| {r['scenario']} | {r['target']} | "+' | '.join(f"{r['jobs'][j]['median_wall_ns']/1e6:.2f}" for j in ['1','2','4','8','16','auto'])+' |']
 s+=['','Values are whole-build milliseconds. All worker variants must emit identical LLVM. Small median differences are not an adoption argument; omitted jobs remains one unless the established representative gain and native-platform gates pass.','']
x=load('scale.json')
if x:
 s+=['## Scaled temporary projects','','Each unit supplies 24 functions using records, explicit generic calls and arithmetic. Wide imports independent modules; shared imports a common foundation; chain imports the next module; heavy puts the same total function count into four modules. Every function contributes to a checked runtime result. Heavy inputs deliberately include deep arithmetic aggregates; they are stress cases, not representative real projects.','','| Units | Shape | Source files | Before j1 (ms) | Final j1 | Final j4 | Final auto | Single-worker speedup |','|---:|---|---:|---:|---:|---:|---:|---:|']
 for r in x['runs']:
  v=r['variants']
  if not all('wall_ms' in c for c in v.values()):continue
  s+=[f"| {r['units']} | {r['shape']} | {r['files']} | "+' | '.join(f"{v[k]['wall_ms']:.1f}" for k in ['before-j1','final-j1','final-j4','final-auto'])+f" | {v['before-j1']['wall_ms']/v['final-j1']['wall_ms']:.2f}× |"]
 s+=['','The scaled baseline is the turn-start compiler, not original main. Every successful build is executed and checked, and LLVM is required to match across compilers and worker counts. Sources remain under `/tmp/nerd-scale-bench-Xo1BUG`; the archived generator recreates them. Per-file source hashes are in the raw scaled results.','', '### Largest-project resource comparison','','| Shape (1,000 units) | Before j1 CPU s / RSS MiB | Final j1 | Final j4 | Final auto |','|---|---:|---:|---:|---:|']
 for r in x['runs']:
  if r['units']!=1000 or not all('wall_ms' in c for c in r['variants'].values()):continue
  s+=[f"| {r['shape']} | "+' | '.join(f"{r['variants'][k]['cpu_seconds']:.2f} / {r['variants'][k]['rss_mib']:.1f}" for k in ['before-j1','final-j1','final-j4','final-auto'])+' |']
s+=['','## Evidence and remaining gates','','Raw JSON, logs, commands, compiler hashes, tool versions, the scaled generator and scripts are archived under `compiler-single-core-final/` as gzip files. `provenance.json.gz` records the exact final timing commands. The active [completion plan](../audits/compiler-single-core-follow-up.md) tracks the milestones. Native Windows/macOS validation remains external; neither the default worker policy nor the withdrawn task-graph decision is changed by these Linux synthetic results.']
(W/'REPORT.md').write_text('\n'.join(s)+'\n')
