from pathlib import Path
import subprocess,sys,json,hashlib,platform,os,time
root=Path('/home/matt/nerd'); out=Path(__file__).parent
commands=[
 ('paired',[sys.executable,'build/benchmark_compare.py','--before','/tmp/nerd-singlecore-start','--after','_bin/nerd','--cpu','2','--jobs','1','--samples','7','--profile-samples','3','--output',str(out/'paired.json')]),
 ('original',[sys.executable,'build/benchmark_main.py','--before','/tmp/nerd-comparison-main','--after','_bin/nerd','--before-ref','a15e965d','--cpus','2','--after-jobs','1','--samples','7','--output',str(out/'original.json')]),
 ('workers',[sys.executable,'build/benchmark_jobs.py','--nerd','_bin/nerd','--cpus',*map(str,range(16)),'--jobs','1','2','4','8','16','auto','--samples','5','--output',str(out/'workers.json')]),
 ('scale',[sys.executable,str(out/'scale.py')]),
]
metadata={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'platform':platform.platform(),'commands':commands,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'compilers':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'_bin/nerd',Path('/tmp/nerd-singlecore-start'),Path('/tmp/nerd-comparison-main')]},'governor':Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor').read_text().strip()}
for tool in ['opt','llc','ld.lld']:
 metadata[tool]=subprocess.check_output([tool,'--version'],text=True).strip()
(out/'provenance.json').write_text(json.dumps(metadata,indent=2))
for name,cmd in commands:
 print('START',name,time.strftime('%H:%M:%S'),flush=True)
 with (out/(name+'.log')).open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,time.strftime('%H:%M:%S'),flush=True)
